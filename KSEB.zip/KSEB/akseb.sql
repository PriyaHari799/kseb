-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 07, 2022 at 01:09 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `akseb`
--

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `id` int(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  `amount` bigint(100) NOT NULL,
  `unit` int(50) NOT NULL,
  `date` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`id`, `name`, `amount`, `unit`, `date`) VALUES
(59, 'Priya Hari', 253, 125, '2022-05-02'),
(74, 'Priya Hari', 450, 125, '2022-05-03'),
(75, 'Priya Hari', 450, 125, '2022-05-03'),
(76, 'Priya Hari', 450, 125, '2022-05-03'),
(77, '', 0, 0, '2022-05-03'),
(78, 'Priya Hari', 450, 125, '2022-05-03'),
(79, 'Priya Hari', 253, 125, '2022-05-03'),
(80, 'Priya Hari', 253, 152, '2022-05-04'),
(81, 'Priya Hari', 253, 152, '2022-05-04'),
(82, 'Priya Hari', 563, 152, '2022-05-05'),
(83, 'Priya Hari', 563, 152, '2022-05-06'),
(84, 'Priya Hari', 563, 152, '2022-05-06'),
(85, 'Priya Hari', 563, 152, '2022-05-06'),
(86, 'Priya Hari', 563, 152, '2022-05-06'),
(87, 'Priya Hari', 563, 152, '2022-05-06'),
(88, 'Priya Hari', 1146, 152, '2022-05-06'),
(89, 'Priya Hari', 583, 152, '2022-05-06'),
(90, 'Priya Hari', 583, 152, '2022-05-06'),
(91, 'Priya Hari', 583, 152, '2022-05-06'),
(92, 'Priya Hari', 583, 152, '2022-05-06'),
(93, 'Priya Hari', 583, 152, '2022-05-06'),
(94, 'Priya Hari', 583, 152, '2022-05-06'),
(95, 'Priya Hari', 583, 152, '2022-05-06');

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `c_id` int(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `consumer` bigint(100) NOT NULL,
  `mobile` bigint(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `village` varchar(50) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `time` time(6) NOT NULL DEFAULT current_timestamp(),
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`c_id`, `username`, `consumer`, `mobile`, `description`, `district`, `village`, `date`, `time`, `status`) VALUES
(30, 'Priya Hari', 1230000000321, 7895862548, 'No supply here', 'Wayanad', 'aroor', '2022-02-23', '22:29:39.000000', 'Completed'),
(32, 'Priya Hari', 1230000000321, 7895482658, 'No power supply here', 'Wayanad', 'aroor', '2022-02-24', '19:38:45.000000', 'Pending'),
(33, 'lisa', 9876456327123, 9985748625, 'No power supply', 'Kottyam', 'kanjirappally', '2022-02-26', '09:13:03.000000', 'Progressing');

-- --------------------------------------------------------

--
-- Table structure for table `lt_tarrif`
--

CREATE TABLE `lt_tarrif` (
  `tarrif` varchar(100) DEFAULT NULL,
  `fix_charge` decimal(10,1) DEFAULT NULL,
  `prunit` decimal(10,1) DEFAULT NULL,
  `e_tax` decimal(10,1) DEFAULT NULL,
  `subsidary` decimal(10,1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lt_tarrif`
--

INSERT INTO `lt_tarrif` (`tarrif`, `fix_charge`, `prunit`, `e_tax`, `subsidary`) VALUES
('commerical', '20.0', '1.5', '101.0', '10.0'),
('public', '20.0', '1.5', '101.0', '10.0'),
('ltcommerical', '20.0', '8.1', '101.0', '10.0'),
('workshop', '20.0', '4.6', '101.0', '10.0'),
('industries', '20.0', '4.0', '101.0', '10.0'),
('power', '20.0', '4.6', '101.0', '10.0'),
('tempsup', '20.0', '12.0', '101.0', '10.0'),
('lighttown', '20.0', '6.4', '101.0', '10.0'),
('govt', '20.0', '5.8', '101.0', '10.0'),
('private', '20.0', '7.5', '101.0', '10.0'),
('commerical', '20.0', '1.5', '101.0', '10.0'),
('public', '20.0', '1.5', '101.0', '10.0'),
('ltcommerical', '20.0', '8.1', '101.0', '10.0'),
('workshop', '20.0', '4.6', '101.0', '10.0'),
('industries', '20.0', '4.0', '101.0', '10.0'),
('power', '20.0', '4.6', '101.0', '10.0'),
('tempsup', '20.0', '12.0', '101.0', '10.0'),
('lighttown', '20.0', '6.4', '101.0', '10.0'),
('govt', '20.0', '5.8', '101.0', '10.0'),
('private', '20.0', '7.5', '101.0', '10.0'),
('commerical', '20.0', '1.5', '101.0', '10.0'),
('public', '20.0', '1.5', '101.0', '10.0'),
('ltcommerical', '20.0', '8.1', '101.0', '10.0'),
('workshop', '20.0', '4.6', '101.0', '10.0'),
('industries', '20.0', '4.0', '101.0', '10.0'),
('power', '20.0', '4.6', '101.0', '10.0'),
('tempsup', '20.0', '12.0', '101.0', '10.0'),
('lighttown', '20.0', '6.4', '101.0', '10.0'),
('govt', '20.0', '5.8', '101.0', '10.0'),
('private', '20.0', '7.5', '101.0', '10.0');

-- --------------------------------------------------------

--
-- Table structure for table `newconnect`
--

CREATE TABLE `newconnect` (
  `n_id` int(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `bname` varchar(100) NOT NULL,
  `bnumber` int(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `village` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `purpose` varchar(100) NOT NULL,
  `appstatus` varchar(30) NOT NULL,
  `p_ownership` varchar(100) NOT NULL,
  `p_identity` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `newconnect`
--

INSERT INTO `newconnect` (`n_id`, `username`, `bname`, `bnumber`, `email`, `district`, `village`, `date`, `purpose`, `appstatus`, `p_ownership`, `p_identity`) VALUES
(28, 'shamaili', 'shamailihouse', 12, 'shamaili@gmail.com', 'Kottyam', 'koovappally', '2022-02-10', 'Domestic', 'Owner', '1372_1597637338_1370_1596692666_aggregated_text_book-First_Module.pdf', 'Vecteezy-License-Information.pdf'),
(29, 'Latha', 'latha house', 54, 'latha@gmail.com', 'Kottyam', 'kangazha', '2022-02-16', 'Domestic', 'Owner', 'proof.pdf', 'identity.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_billdetails`
--

CREATE TABLE `tbl_billdetails` (
  `bill_id` int(50) NOT NULL,
  `c_name` varchar(50) NOT NULL,
  `c_number` bigint(100) NOT NULL,
  `c_unit` int(100) NOT NULL,
  `gen_date` varchar(10) NOT NULL,
  `duedate` varchar(50) NOT NULL,
  `discon_date` varchar(50) NOT NULL,
  `pay_amount` int(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `date` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_billdetails`
--

INSERT INTO `tbl_billdetails` (`bill_id`, `c_name`, `c_number`, `c_unit`, `gen_date`, `duedate`, `discon_date`, `pay_amount`, `status`, `date`) VALUES
(46, 'Sara', 1230000000321, 123, '05', '2022-05-04', '2022-05-08', 532, 'Pending', '2022-05-04'),
(55, 'Hema David', 1568963524712, 152, '05', '2022-05-06', '2022-05-20', 523, 'Completed', '2022-05-06'),
(59, 'Sara', 2345768905678, 152, '05', '2022-05-06', '2022-05-20', 335, 'Pending', '2022-05-05'),
(60, 'Priya Hari', 1230000000321, 152, '05', '2022-05-07', '2022-05-19', 583, 'Pending', '2022-05-06'),
(61, 'Swathi', 9977665434874, 100, '05', '2022-05-12', '2022-05-21', 253, 'Pending', '2022-05-06');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employreg`
--

CREATE TABLE `tbl_employreg` (
  `emp_id` int(50) NOT NULL,
  `Type_Id` int(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `phone` bigint(50) NOT NULL,
  `Section` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `status` int(50) NOT NULL DEFAULT 2
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_employreg`
--

INSERT INTO `tbl_employreg` (`emp_id`, `Type_Id`, `Name`, `Address`, `Email`, `phone`, `Section`, `password`, `status`) VALUES
(1, 1, 'Harikuttan tv', 'Thazhathepeedikayil,kavumbhagom P O, Cheruvally', 'harikuttan@gmail.com', 7895412875, 'Ponkunnam', 'Hari@123', 2),
(2, 2, 'swasthika', 'Swasthika villa, plappallil P O, Kottyam', 'dreamgirl944640@gmail.com', 9985632147, 'Ponkunnam', 'Swasthika@123', 2),
(3, 3, 'Divya', 'Divya villa, Kottyam', 'divya@gmail.com', 7895214762, 'Manimala', 'Divya@123', 2),
(4, 3, 'krishnapriya', 'krishna villa, kanjirappally PO, Kottyam', 'krishna@gmail.com', 8895214756, 'Kanjirappally', 'Krishna@123', 2),
(6, 1, 'Shivas M', 'shivas villa, kanjirappally PO , Kanjirappally, ko', 'shivas@gmail.com', 9952147358, 'Manimala', 'Shivas@1234', 2),
(7, 3, 'Karthika Das', 'karthika villa, Kottayam', 'karthika@gmail.com', 9985231478, 'Ponkunnam', 'Karthika@123', 2),
(8, 3, 'Latha VS', 'Latha villa, Kanjirapally, Kottyam', 'latha@gmail.com', 7892358412, 'Manimala', 'Latha@123', 2),
(9, 2, 'Sruthi Das', 'Kottkkal, Manimala ,Kottyam', 'sruthi@gmail.com', 7665892147, 'Manimala', 'Sruthi@123', 2),
(11, 2, 'Dilsa Sajan', 'Dilsa villa,\r\npaika', 'dilsa@gmail.com', 8965214236, 'Ponkunnam', 'Dilsa@123', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_leave`
--

CREATE TABLE `tbl_leave` (
  `l_id` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `leave_type` varchar(50) NOT NULL,
  `from_date` varchar(50) NOT NULL,
  `to_date` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL,
  `total_leave` int(50) NOT NULL,
  `section` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_leave`
--

INSERT INTO `tbl_leave` (`l_id`, `name`, `leave_type`, `from_date`, `to_date`, `description`, `total_leave`, `section`, `Email`, `status`) VALUES
(96, 'Divya', 'Casual Leave', '2022-04-14', '2022-04-17', 'Medical', 4, 'Manimala', 'divya@gmail.com', 'Approved'),
(111, 'Harikuttan tv', 'Casual Leave', '2022-04-14', '2022-04-17', 'Medical', 4, 'Ponkunnam', 'harikuttan@gmail.com', 'Approved'),
(114, 'Divya', 'Casual Leave', '2022-04-19', '2022-04-21', 'Medical', 3, 'Manimala', 'divya@gmail.com', 'Pending'),
(122, 'Harikuttan tv', 'Casual Leave', '2022-04-19', '2022-04-21', 'Medical', 3, 'Ponkunnam', 'harikuttan@gmail.com', 'Pending'),
(125, 'swasthika', 'Casual Leave', '2022-05-05', '2022-05-07', 'medical', 3, 'Ponkunnam', 'dreamgirl944640@gmail.com', 'Pending'),
(128, 'Harikuttan tv', 'Casual Leave', '2022-05-06', '2022-05-06', 'medical', 1, 'Ponkunnam', 'harikuttan@gmail.com', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_metershift`
--

CREATE TABLE `tbl_metershift` (
  `c_id` int(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `consumer` bigint(50) NOT NULL,
  `mobile` bigint(50) NOT NULL,
  `reason` varchar(50) NOT NULL,
  `district` varchar(50) NOT NULL,
  `village` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_metershift`
--

INSERT INTO `tbl_metershift` (`c_id`, `username`, `consumer`, `mobile`, `reason`, `district`, `village`, `date`, `status`) VALUES
(1, 'Priya Hari', 1156330000321, 8547556987, 'construction purpose', 'Kottyam', 'Manimala', '2022-03-05', 'Accepted'),
(2, 'lisa', 1145762587013, 9876459432, 'construction ', 'Kottyam', 'koovappally', '2022-03-05', 'Rejected');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_notifications`
--

CREATE TABLE `tbl_notifications` (
  `n_id` int(50) NOT NULL,
  `notifications_name` varchar(50) NOT NULL,
  `message` varchar(1000) NOT NULL,
  `date` varchar(10) NOT NULL,
  `status` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_notifications`
--

INSERT INTO `tbl_notifications` (`n_id`, `notifications_name`, `message`, `date`, `status`) VALUES
(6, 'KSEB New Services', ' KSEB to induct 65 Electric Vehicles on its 65th anniversary.', '2022-05-07', 0),
(7, 'Kseb news latest', 'India\'s Largest Floating Solar Power Plant in Kerala to Start Operations Today.', '2022-05-07', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_overvisit`
--

CREATE TABLE `tbl_overvisit` (
  `o_id` int(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  `Phone` bigint(50) NOT NULL,
  `Section` varchar(50) NOT NULL,
  `num_visit` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_overvisit`
--

INSERT INTO `tbl_overvisit` (`o_id`, `Name`, `Email`, `date`, `Phone`, `Section`, `num_visit`) VALUES
(2, 'swasthika', 'dreamgirl944640@gmail.com', '2022-03-07', 9985632147, 'Ponkunnam', '5');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_promotion`
--

CREATE TABLE `tbl_promotion` (
  `p_id` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `position` varchar(50) NOT NULL,
  `ownership` varchar(100) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `section` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_promotion`
--

INSERT INTO `tbl_promotion` (`p_id`, `name`, `position`, `ownership`, `Email`, `section`) VALUES
(7, 'Latha VS', 'Assistant Engineer', 'eg.pdf', 'latha@gmail.com', 'Manimala');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_report`
--

CREATE TABLE `tbl_report` (
  `re_id` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `section` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `record` text NOT NULL,
  `date` varchar(50) NOT NULL,
  `report` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_report`
--

INSERT INTO `tbl_report` (`re_id`, `name`, `section`, `email`, `title`, `record`, `date`, `report`, `status`) VALUES
(15, 'swasthika', 'Ponkunnam', 'dreamgirl944640@gmail.com', 'Overseer_Report', '<p>The Kerala State Electricity Board, constituted by the Government of Kerala, by order dated 7 March 1957, under the Electricity (Supply) Act, 1948 is in the business of Generation, Transmission and Distribution of electricity and striving to provide quality electricity<sup>[<em><a href=\"https://en.wikipedia.org/wiki/Wikipedia:Please_clarify\" title=\"Wikipedia:Please clarify\">clarification needed</a></em>]</sup>&nbsp;at affordable cost to all classes of consumers in the state of Kerala.Kerala State Electricity Board commenced functioning on 31 March 1957 After Noon as per order no. EL1-6475/56/PW dated 7 March 1957 of the Kerala State Government. It had 5 members with Sri K P Sreedharan Nair as chairman. All the staff belonging to the erstwhile Electricity Department was transferred to the Board. The &#39;Board&#39; consisting of the chairman and the Members is the Supreme Governing Body.</p>\r\n\r\n<p>The State Government by their notification EL3-9345 dated 21 February 1958 constituted the State Electricity Consultative Council under section 16 of the Electricity Supply Act. The Council functions as consultative body and the Board is required to place before the council the annual financial statement and supplementary statements if any before submitting such statements to the State Government. The &#39;Board&#39; consisting of the chairman and the Members is the Supreme Governing Body. The Board consists of seven members and is headed by the chairman. The Government of Kerala and KSE Board issued orders for the restructuring of KSE Board into profit centres in April 2002. Members head the profit centres. There is a Corporate Office to co-ordinate and control the activities of the Board.</p>\r\n', '2022-04-03', 'ed1.pdf', 'Uploaded');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_type`
--

CREATE TABLE `tbl_type` (
  `Type_Id` int(50) NOT NULL,
  `Type` varchar(100) NOT NULL,
  `status` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_type`
--

INSERT INTO `tbl_type` (`Type_Id`, `Type`, `status`) VALUES
(1, 'Meter Reader', 1),
(2, 'Overseer', 0),
(3, 'Sub-Engineers', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_usereg`
--

CREATE TABLE `tbl_usereg` (
  `reg_id` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `consnumber` bigint(50) NOT NULL,
  `phone` bigint(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `status` int(59) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_usereg`
--

INSERT INTO `tbl_usereg` (`reg_id`, `name`, `email`, `consnumber`, `phone`, `username`, `password`, `status`) VALUES
(12, 'sivas', 'sivas123@gmail.com', 1156331158963, 7799547643, 'Sivas', 'Shiva@1234', 1),
(14, 'Divyareji', 'divyareji@gmail.com', 4567098734567, 9876874356, 'divyareji', 'Divya@123', 1),
(15, 'Sara', 'sara@gmail.com', 5678954367965, 9678943567, 'Sara', 'Sara@123', 1),
(16, 'neenasomar', 'neenasomar@gmail.com', 2345768905678, 7896544398, 'neena', 'Neena@123', 1),
(17, 'Ayya', 'ayyan@gmail.com', 3456786510963, 7994076945, 'Ayyappan', 'Ayyan@123', 1),
(18, 'Swathi', 'swathi@gmail.com', 9977665434874, 8965432876, 'Swathi', 'Swathi@123', 1),
(19, 'Lisa', 'lisa@gmail.com', 1145762587013, 9876459432, 'lisa', 'Lisa@123456', 1),
(24, 'diya', 'diya@gmail.com', 9456785421536, 9954782456, 'Diya', 'Diya@12345', 1),
(26, 'Anna', 'anna@gmail.com', 9876543567324, 8765432678, 'Anna', 'Anna@123', 1),
(27, 'Athira', 'athira@gmail.com', 1109345700032, 9875234581, 'Athira', 'Athira@123', 1),
(28, 'Danya', 'danya@gmail.com', 1187653400078, 9975437722, 'Danya', 'Danya@1234', 1),
(30, 'Priya Hari', 'priya799@gmail.com', 1230000000321, 8547556987, 'Priya Hari', 'Priyahari@123', 1),
(31, 'jinu', 'jinu@gmail.com', 1000000000123, 7994076955, 'Jinu', 'Jinu@123', 1),
(32, 'bahubali', 'bahubali@gmail.com', 7893784567891, 9495170441, 'bahubali', 'kattappa@123', 1),
(33, 'nithya', 'nithya@gmail.com', 1000000000124, 7994076922, 'nithya', 'Nithya@123', 1),
(34, 'jobin', 'jobin@gmail.com', 1000000000321, 7994076955, 'jobin', 'Jobin@123', 1),
(35, 'popo', 'popo@gmail.com', 1000000000789, 9446409321, 'popo', 'Popod@123', 1),
(37, 'Hari', 'hari123@gmail.com', 1165810000228, 8574112367, 'Hari', 'Hari@123', 1),
(38, 'admin', 'admin@gmail.com', 0, 1912, 'admin', 'admin@123', 2),
(42, 'Hema David', 'hema@gmail.com', 1568963524712, 8896257145, 'Hema David', 'Hema@123', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `newconnect`
--
ALTER TABLE `newconnect`
  ADD PRIMARY KEY (`n_id`);

--
-- Indexes for table `tbl_billdetails`
--
ALTER TABLE `tbl_billdetails`
  ADD PRIMARY KEY (`bill_id`);

--
-- Indexes for table `tbl_employreg`
--
ALTER TABLE `tbl_employreg`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `tbl_leave`
--
ALTER TABLE `tbl_leave`
  ADD PRIMARY KEY (`l_id`);

--
-- Indexes for table `tbl_metershift`
--
ALTER TABLE `tbl_metershift`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `tbl_notifications`
--
ALTER TABLE `tbl_notifications`
  ADD PRIMARY KEY (`n_id`);

--
-- Indexes for table `tbl_overvisit`
--
ALTER TABLE `tbl_overvisit`
  ADD PRIMARY KEY (`o_id`);

--
-- Indexes for table `tbl_promotion`
--
ALTER TABLE `tbl_promotion`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `tbl_report`
--
ALTER TABLE `tbl_report`
  ADD PRIMARY KEY (`re_id`);

--
-- Indexes for table `tbl_type`
--
ALTER TABLE `tbl_type`
  ADD PRIMARY KEY (`Type_Id`);

--
-- Indexes for table `tbl_usereg`
--
ALTER TABLE `tbl_usereg`
  ADD PRIMARY KEY (`reg_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bill`
--
ALTER TABLE `bill`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;

--
-- AUTO_INCREMENT for table `complaints`
--
ALTER TABLE `complaints`
  MODIFY `c_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `newconnect`
--
ALTER TABLE `newconnect`
  MODIFY `n_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `tbl_billdetails`
--
ALTER TABLE `tbl_billdetails`
  MODIFY `bill_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `tbl_employreg`
--
ALTER TABLE `tbl_employreg`
  MODIFY `emp_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_leave`
--
ALTER TABLE `tbl_leave`
  MODIFY `l_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=129;

--
-- AUTO_INCREMENT for table `tbl_metershift`
--
ALTER TABLE `tbl_metershift`
  MODIFY `c_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_notifications`
--
ALTER TABLE `tbl_notifications`
  MODIFY `n_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_overvisit`
--
ALTER TABLE `tbl_overvisit`
  MODIFY `o_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_promotion`
--
ALTER TABLE `tbl_promotion`
  MODIFY `p_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_report`
--
ALTER TABLE `tbl_report`
  MODIFY `re_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tbl_type`
--
ALTER TABLE `tbl_type`
  MODIFY `Type_Id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_usereg`
--
ALTER TABLE `tbl_usereg`
  MODIFY `reg_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
