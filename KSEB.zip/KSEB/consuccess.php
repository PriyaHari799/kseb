

<html>
    <head>
    
    
    <style>

body {
  background-image: url("images/intro-bg.jpg");
  background-color:#cce0ff;
  
}

        h1 {
          color: #fffff;
          
          
        
          margin-bottom: 10px;
        }
        p {

         
          font-size:20px;
          margin: 0;
        }
      i {
        color:white;
        font-size: 100px;
        line-height: 200px;
        margin-left:-15px;
      }
      .card {
        background: white;
        padding: 60px;
        border-radius: 4px;
        box-shadow: 0 2px 3px #C8D0D8;
        display: inline-block;
        margin: 0 auto;
      }
    






    </style>
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
   
</head>

<body>
<div id="content">

            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">
                <a class="navbar-brand" href="meterhome.php">
      <img src="images/log.png" alt="" width="40" height="35" class="d-inline-block align-text-top">
      <b>KSEB NEW CONNECTION PORTAL</b>
    </a>
                   

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="nav navbar-nav ml-auto">
                          
                        <li class="nav-item">
                        <a href="index.php"><button type="button" class="btn btn-primary btn-arrow-left">BACK TO HOME</button></a>
                            </li>

                            
                        
                        </ul>
                    </div>
                </div>
            </nav>


</head>
<center><br><br><br>
            <body>
            <div class="card" style="width: 32rem;">
      <div style="border-radius:150px; height:150px; width:150px; background:#1aa3ff; margin:0 auto;">
        <i class="checkmark">✓</i>
      </div>
        <h4>Connection Registration Success</h4> 
        <p>We will get in touch with you within <br>24 Hours.</p>
        
      </div>
    </body>
    </center>



            

</html>

