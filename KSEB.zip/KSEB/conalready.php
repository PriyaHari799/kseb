

<html>
    <head>
    
    
    <style>

body {
  background-image: url("images/intro-bg.jpg");
  background-color:#cce0ff;
  
}

        h1 {
          color: #fffff;
          
          
        
          margin-bottom: 10px;
        }
        p {

         
          font-size:20px;
          margin: 0;
        }
      i {
        color:white;
        font-size: 100px;
        line-height: 200px;
        margin-left:-15px;
      }
      .card {
        background: white;
        padding: 60px;
        border-radius: 4px;
        box-shadow: 0 2px 3px #C8D0D8;
        display: inline-block;
        margin: 0 auto;
      }
    






    </style>
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
   
</head>

<body>
<div id="content">

            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">
                <a class="navbar-brand" href="meterhome.php">
      <img src="images/log.png" alt="" width="40" height="35" class="d-inline-block align-text-top">
      <b>KSEB NEW CONNECTION PORTAL</b>
    </a>
                   

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="nav navbar-nav ml-auto">
                          
                        <li class="nav-item">
                        <a href="index.html"><button type="button" class="btn btn-primary btn-arrow-left">BACK TO HOME</button></a>
                            </li>

                            
                        
                        </ul>
                    </div>
                </div>
            </nav>


</head>
<center><br><br><br>
            <body>
            <div class="card" style="width: 32rem;">
      <div style="border-radius:150px; height:100px; width:100px; background:#ff4000; margin:0 auto;">
      <p style="font-size:60px;"><b>X</b></p>
     
      </div>
        <h4> Oops..<br>You Already apply for the Connection.</h4> 
        <p>For more queries please contact with 1912.</p>
      </div>
    </body>
    </center>



            

</html>

